# StudyFix AI V2

Frontend: index.html
Backend: server.js

Set `OPENAI_API_KEY` as a server environment variable. Never put it in the HTML. Run `npm install` then `npm start`.
